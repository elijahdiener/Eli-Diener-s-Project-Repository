const button = document.getElementById('doCalculation');

button.addEventListener('click', calculate);

function calculate() {

    let text1 = document.getElementById('first-num');
    let text2 = document.getElementById('second-num');
    let output = document.getElementById('result');
    let num1 = parseFloat(text1.value);
    let num2 = parseFloat(text2.value);
    let result = 0;

    let element = document.getElementsByName('operator');

    for (i = 0; i < element.length; i++) {
        if (element[i].checked) {
            if (element[i].value == "plus") {
                result = num1 + num2;
                output.innerText = result;
            }
            else if (element[i].value == "minus") {
                result = num1 - num2;
                output.innerText = result;
            }
            else if (element[i].value == "multiply") {
                result = num1 * num2;
                output.innerText = result;
            }
            else if (element[i].value == "divide") {
                if (num2 != 0) {
                    result = num1 / num2;
                    output.innerText = result;
                }
                else {
                    output.innerText = "Error: cannot divide by zero";
                }
            }
        }
    }
}